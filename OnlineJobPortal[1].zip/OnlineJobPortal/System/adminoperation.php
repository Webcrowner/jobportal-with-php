<?php
session_start();

if (!isset($_SESSION['logged']) || $_SESSION['role'] != 'admin') {
    header("location: ../login.php");
    exit();
}

// Include your database connection file
require '../constants/db_config.php';

// Function to fetch users based on their role
function getUsersByRole($conn, $role)
{
    $stmt = $conn->prepare("SELECT * FROM tbl_users WHERE role = :role");
    $stmt->bindParam(':role', $role);
    $stmt->execute();
    return $stmt->fetchAll();
}

// Function to delete a user by their ID
function deleteUser($conn, $userId)
{
    $stmt = $conn->prepare("DELETE FROM tbl_users WHERE member_no = :userId");
    $stmt->bindParam(':userId', $userId);
    $stmt->execute();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Include any additional styles or scripts here -->
</head>

<body>

    <h1>Welcome, <?php echo $_SESSION['myfname']; ?> (Admin)</h1>

    <h2>Manage Employee Accounts</h2>
    <?php
    $employees = getUsersByRole($conn, 'employee');

    foreach ($employees as $employee) {
        echo "<p>{$employee['first_name']} {$employee['last_name']} - <a href='view_profile.php?id={$employee['member_no']}'>View Profile</a> | <a href='delete_user.php?id={$employee['member_no']}'>Delete User</a></p>";
    }
    ?>

    <h2>Manage Employer Accounts</h2>
    <?php
    $employers = getUsersByRole($conn, 'employer');

    foreach ($employers as $employer) {
        echo "<p>{$employer['first_name']} ({$employer['title']}) - <a href='view_profile.php?id={$employer['member_no']}'>View Profile</a> | <a href='delete_user.php?id={$employer['member_no']}'>Delete User</a></p>";
    }
    ?>

    <!-- Include any additional content or features as needed -->

</body>

</html>
